# TeamOGxShaikh Gaming App

Android Studio project wrapping the TeamOGxShaikh gaming web prototype in a native Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Test on an Android device/emulator.
4. For Play Store: Build > Generate Signed Bundle / APK > Android App Bundle.
5. Create a release keystore and securely store it.
6. Upload the generated `.aab` to Google Play Console.

Package name: com.teamogxshaikh.gaming
Version: 1.0 (code 1)

Before publishing, replace placeholder content with your final privacy policy, support contact, screenshots, app icon, and any required store listing information.
